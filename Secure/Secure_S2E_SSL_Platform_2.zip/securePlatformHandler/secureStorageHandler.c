
#include <string.h>
#include "flashHandler.h"
#include "deviceHandler.h"
#include "secureStorageHandler.h"
#include "memory_define.h"

#ifdef _STORAGE_DEBUG_
    #include <stdio.h>
#endif

#ifdef __USE_EXT_EEPROM__
    #include "eepromHandler.h"
    uint16_t convert_eeprom_addr(uint32_t flash_addr);
#endif

int secure_read_storage(teDATASTORAGE stype, uint32_t addr, void *data, uint16_t size)
{
    int ret = -1;
    
    switch(stype)
    {
        case STORAGE_MAC:
            //ret = read_flash(OTP_BASE, data, size);
            break;
        
        case STORAGE_CONFIG:
            ret = read_flash(S_FLASH_DEV_INFO_ADDR, data, size);
            break;
        
        case STORAGE_APP_MAIN:
            ret = read_flash(addr, data, size);
            break;
        
        case STORAGE_APP_BACKUP:
            ret = read_flash(addr, data, size);
            break;

        case STORAGE_ROOTCA:
            ret = read_flash(S_FLASH_ROOTCA_ADDR, data, size);
            break;

        case STORAGE_CLICA:
            ret = read_flash(S_FLASH_CLICA_ADDR, data, size);
            break;  
        
        case STORAGE_PKEY:
            ret = read_flash(S_FLASH_PKEY_ADDR, data, size);
            break;  
            
        default:
            break;
    }
    
    return ret;
}


int secure_write_storage(teDATASTORAGE stype, uint32_t addr, void *data, uint16_t size)
{
    int ret = -1;
    
    switch(stype)
    {
        case STORAGE_MAC:
            //ret = write_flash(OTP_BASE, data, size);
            break;
        
        case STORAGE_CONFIG:
            ret = write_flash(S_FLASH_DEV_INFO_ADDR, data, size);
            break;
        
        case STORAGE_APPBOOT:
        case STORAGE_APP_MAIN:
            //ret_len = write_flash(addr, data, size);
            break;

        case STORAGE_APP_BACKUP:
            //ret_len = write_sflash(addr, data, size); // serial flash bank for main application download / backup
            break;
            
        case STORAGE_ROOTCA:
            ret = write_flash(S_FLASH_ROOTCA_ADDR, data, size);
            break;

        case STORAGE_CLICA:
            ret = write_flash(S_FLASH_CLICA_ADDR, data, size);
            break;  
        
        case STORAGE_PKEY:
            ret = write_flash(S_FLASH_PKEY_ADDR, data, size);
            break;  

        default:
            break;
    }
    
    return ret;
}

int secure_erase_storage(teDATASTORAGE stype)
{
    uint16_t i;
    uint32_t address, working_address;
    
    uint8_t blocks = 0;
    uint16_t sectors = 0, remainder = 0;

    int ret = -1;
    
    switch(stype)
    {
        case STORAGE_MAC:
            printf("can't erase MAC in f/w, use stm32cube programmer\r\n");
            break;
        
        case STORAGE_CONFIG:
            ret = erase_flash_page(S_FLASH_DEV_INFO_ADDR);
#if USE_SINGLE_BANK
            if (ret < 0 )
                return ret;
            ret = erase_flash_page(S_FLASH_DEV_INFO_ADDR + FLASH_BANK_PAGE_SIZE);
#endif
            break;
        
        case STORAGE_APP_MAIN:
            //address = DEVICE_APP_ADDR;
            break;
        
        case STORAGE_APP_BACKUP:
            //address = DEVICE_APP_ADDR;
            break;
        
        case STORAGE_APPBOOT:
            //address = DEVICE_BOOT_ADDR;
            break;
            
        case STORAGE_ROOTCA:
            ret = erase_flash_page(S_FLASH_ROOTCA_ADDR);
            break;

        case STORAGE_CLICA:
            ret = erase_flash_page(S_FLASH_CLICA_ADDR);
            break;  
        
        case STORAGE_PKEY:
            ret = erase_flash_page(S_FLASH_PKEY_ADDR);
            break;
        
        default:
            break;
    }
    return ret;
}

#ifdef __USE_EXT_EEPROM__
uint16_t convert_eeprom_addr(uint32_t flash_addr)
{
    return (uint16_t)(flash_addr-DAT0_START_ADDR);
}
#endif

